GitHub Link: https://github.com/stemmlerjs/os-design-assign-2

Note, you may have to put the java files in a folder called "assignment2"
and run them using java assignment2.EchoServer since they are in the assignment2 package.

Screenshots are included for both questions.

Group Members:
Nelson Elliott
Khalil Stemmler